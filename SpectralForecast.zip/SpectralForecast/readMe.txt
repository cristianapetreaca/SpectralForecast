Petreaca Maria-Cristiana 
1240F

"An implementation after: Paul A. Gagniuc et al. Spectral Forecast. Ageneral purpose prediction model as an alternative to classical neural networks.
Chaos 30. 0331199(2020); doi: 10.1063/1.5120818"

https://aip.scitation.org/doi/10.1063/1.5120818